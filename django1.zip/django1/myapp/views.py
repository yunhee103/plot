from django.shortcuts import render
from django.conf import settings # Django 설정 파일을 불러옵니다. BASE_DIR과 같은 설정값에 접근할 수 있습니다.
from pathlib import Path
import seaborn as sns
import matplotlib
matplotlib.use('Agg') #matplotlib이 그래프를 그릴 때 backend로 지정하는 코드  / 
# 기본은 그래프 창이 열리는데 Agg, PDF -> GUI없이 시각화를 파일로 저장
import matplotlib.pyplot as plt


# Create your views here.
def main(request):
    return render(request, 'main.html')

def showdata(request):
    """
    아이리스(iris) 데이터셋을 로드하고, 종(species)의 비율을 파이 차트로 시각화하여
    지정된 경로에 이미지 파일로 저장하는 함수입니다.
    """
    # 1. 데이터 로딩
    # seaborn 라이브러리에 내장된 'iris' 데이터셋을 pandas DataFrame 형식으로 불러옵니다.
    df = sns.load_dataset('iris') 
    
    # 2. 이미지 저장 경로 설정
    # settings.BASE_DIR은 Django 프로젝트의 기본 디렉터리 경로입니다.
    # 'static/images' 폴더 안에 iris.png 파일을 저장하기 위한 경로를 설정합니다.
    static_app_dir = Path(settings.BASE_DIR) / 'static' / 'images'
    
    # 설정된 경로(static/images)에 디렉터리가 없으면 생성합니다.
    # parents=True는 부모 디렉터리까지 함께 생성하도록 하고, exist_ok=True는 이미 디렉터리가 존재해도 오류를 발생시키지 않도록 합니다.
    static_app_dir.mkdir(parents=True, exist_ok=True)
    
    # 이미지 파일의 최종 저장 경로(예: /path/to/project/static/images/iris.png)를 정의합니다.
    img_path = static_app_dir / 'iris.png'
    
    # 3. 파이 차트 생성 및 저장
    # 'species' 컬럼의 값별 개수를 세어 Series 형태로 반환합니다.
    # .sort_index()를 사용해 인덱스(종류)별로 정렬합니다.
    counts = df['species'].value_counts().sort_index()
    
    # 각 종의 개수를 콘솔에 출력하여 확인합니다.
    print('counts : ', counts)
    
    # 새로운 그림(figure) 객체를 생성합니다.
    plt.figure()
    
    # pandas의 plot.pie() 메서드를 사용하여 파이 차트를 그립니다.
    # autopct='%1.1f%%'는 각 조각에 소수점 첫째 자리까지의 비율(%)을 표시합니다.
    # startangle=90은 첫 번째 조각이 90도(위쪽)에서 시작하도록 설정합니다.
    # ylable=''는 y축 라벨을 제거합니다.
    counts.plot.pie(autopct='%1.1f%%', startangle=90, ylabel='') 
    
    # 차트의 제목을 설정합니다.
    plt.title('iris species count')
    
    # 원형 차트가 타원이 아닌 정원 모양으로 보이도록 종횡비를 동일하게 설정합니다.
    plt.axis('equal')
    
    # 플롯 주변 여백을 자동으로 조정하여 텍스트가 잘리지 않도록 합니다.
    plt.tight_layout()
    
    # 생성된 파이 차트를 img_path에 지정된 경로로 이미지 파일로 저장합니다.
    # dpi=130은 이미지의 해상도를 130DPI로 설정합니다.
    plt.savefig(img_path, dpi=130)
    
    plt.close()
    #df를 table tag로 만들어 show.html에 전달
    table_html = df.to_html(classes='table table=striped table-sm', index=False)
 
    return render(request, 'show.html', {
       'table' : table_html,
       'img_relpath':'images/iris.png'
    })


