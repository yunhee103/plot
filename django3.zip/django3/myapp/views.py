from django.shortcuts import render
from django.db import connection #Django의 컨텍스트 매니저를 사용하여 커서 객체를 생성/ 이 방식은 커서 사용이 끝나면 자동으로 닫아주기 때문에 안전
from django.utils.html import escape
import pandas as pd


from django.http import HttpResponse
import matplotlib.pyplot as plt
import io
import base64
plt.rcParams['font.family'] = 'Malgun Gothic'

# Create your views here.
def indexFunc(request):
    return render(request, 'index.html')

def dbshowFunc(request):
    # dbshow.html 템플릿을 렌더링해서 반환합니다.
    dept = request.GET.get('dept',"").strip()
    sql = """
        select j.jikwonno as 직원번호,j.jikwonname as 직원명,
        b.busername as 부서명,b.busertel as 부서전화, 
        j.busernum as 부서번호,
        j.jikwonpay as 연봉,j.jikwonjik as 직급, 
        YEAR(CURDATE()) - YEAR(j.jikwonibsail) AS 근무년수,
        j.jikwongen AS 성별
        FROM jikwon j INNER JOIN buser b
        ON j.busernum = b.buserno
    """
    params = []
    # dept 값이 있으면 WHERE 절 추가
    if dept:
        sql += " where busername like %s"
        params.append(f"%{dept}%")  #SQL 해킹 방지(시큐어 코딩 가이드 라인)
    sql += " order by j.busernum, j.jikwonname ASC"
    
    with connection.cursor() as cur:  # Django의 컨텍스트 매니저를 사용하여 커서 객체를 생성 
        cur.execute(sql, params) # SQL 쿼리 params 리스트에 담긴 값들이 sql 쿼리 내의 %s에 순서대로 바인딩. 파라미터 바인딩을 사용하면 SQL 인젝션 공격을 방지
        rows = cur.fetchall() #rows 변수에 저장
        print(cur.description)
        cols = [c[0] for c in cur.description]
        print('cols :' ,cols)

    df = pd.DataFrame(rows, columns=cols)
    print(df.head(3))


    graph_base64 = None

    #join 결과로 html 생성
    if not df.empty:
        join_html = df[['직원번호', '직원명', '부서번호','부서명', '부서전화', '연봉', '직급', '근무년수', '성별']].to_html(index=False)
    else:
        join_html = '조회된 자료가 없어요'

    #직급별 연봉 통계표 (NaN -> 0 처리)
    if not df.empty:
        stats_df = (
            df.groupby("직급")["연봉"]
                .agg(평균="mean", 표준편차= lambda x:x.std(ddof=0), 인원수="count")
                .round(2)
                .reset_index()
                .sort_values(by="평균", ascending=False) #내림차순 정렬
        )
        
        # 2) 부서명과 직급별 연봉 합 및 평균을 계산하고 HTML 테이블로 변환합니다.
        grouped_stats = df.groupby("부서명")["연봉"].agg(['sum', 'mean']).reset_index().round(2)
        stats_html = grouped_stats.to_html(index=False, classes='table')
        
        # 3) 부서명별 연봉 합, 평균을 이용한 세로막대 그래프를 생성합니다.
        dept_stats = df.groupby("부서명")["연봉"].agg(['sum', 'mean']).reset_index()
        
        plt.figure(figsize=(10, 6))
        
        plt.bar(dept_stats["부서명"], dept_stats["sum"], label="연봉 합", color="#1f77b4")
        
        ax2 = plt.twinx()
        ax2.plot(dept_stats["부서명"], dept_stats["mean"], 'ro-', label="연봉 평균")
        ax2.set_ylabel("연봉 평균")
        ax2.legend(loc='upper right')
        
        plt.title("부서별 연봉 합 및 평균")
        plt.xlabel("부서명")
        plt.ylabel("연봉 합")
        plt.xticks(rotation=45, ha="right")
        plt.legend(loc='upper left')
        plt.tight_layout()
        
        # 생성된 그래프를 PNG 이미지로 메모리에 저장한 후 Base64로 인코딩합니다.
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        graph_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        plt.close()
        
        # 4) 성별, 직급별 빈도표를 계산하고 HTML 테이블로 변환합니다.
        freq_table = pd.crosstab(df["성별"], df["직급"])
        freq_html = freq_table.to_html(classes='table')
        stats_df['표준편차'] = stats_df['표준편차'].fillna(0)
        stats_html = stats_df.to_html(index=False)


    else:
        stats_html = "통계 대상 자료가 없어요"
        join_html = "조회된 자료가 없어요"
        stats_html = "통계 대상 자료가 없어요"
        freq_html = "빈도표 대상 자료가 없어요"
 
    ctx_dict = {
        'dept' : escape(dept),  #(escape는 문자열에 특수문자가 있는 경우 html 엔티티로 치환하는 역할/ 단순문자취급) 해킹방지 
                                # 예) escape('<script>alter(1)</script>  -> '&lt;script&gt; ....) 문자 처리함 
        'join_html' : join_html,
        'stats_html' : stats_html,        
        'freq_html': freq_html,
        'graph_base64': graph_base64,

    }

    return render(request, 'dbshow.html', ctx_dict)
